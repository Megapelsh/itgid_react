import './App.css';
import goodsArr from './goods.json';
import React, {useState} from 'react';
import Goods from './Goods';



function App() {

  const [cart, setCart] = useState({})
  const [count, setCount] = useState(0)

  function addToCart (event) {
    event.preventDefault();
    if (!event.target.classList.contains('add-to-cart')) return false;
    
    console.log(count)
    console.log(event.target.dataset.key)
    let cartTemp = event.target.dataset.key;
    cart[cartTemp] ? setCart(cart[cartTemp] = cart[cartTemp]++) : setCart(cart[cartTemp] = 1)
    console.log(cart)
    // cartTemp[event.target.dataset.key] ? cartTemp[event.target.dataset.key]++ : cartTemp[event.target.dataset.key] = 1;
    // // cartTemp++;
    // setCart(cartTemp);
    // let count = count; 
    // count++;
    // setCount(count)

  }

  return (
    <div className="container">
      <h1>Cart</h1>
      <div className="goods-field" onClick={addToCart}>
      {goodsArr.map(item => <Goods title={item.title} cost={item.cost} image={item.image} articul={item.articul} key={item.articul}/>)}
      </div>
    </div>
  );
}

export default App;
