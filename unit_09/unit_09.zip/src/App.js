import './App.css';

import Comment2Hook from './Comment2Hook';

function App() {
  return (
    <>
      <Comment2Hook />
    </>
  );
}

export default App;
