function Error404 () {
    return (
        <>
            <h1>
                Oops... The page does not exists!
            </h1>
        </>
    );
}

export default Error404;